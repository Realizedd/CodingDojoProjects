from system.core.controller import *

class Surveys(Controller):
    def __init__(self, action):
        super(Surveys, self).__init__(action)

    def index(self):
    	if "counter" not in session:
    		session['counter'] = 0

        return self.load_view('index.html')

    def result(self):
    	name = session['name']
    	session.pop('name')
    	location = session['location']
    	session.pop('location')
    	language = session['language']
    	session.pop('language')
    	comment = "No comment"

    	if "comment" in session:
    		comment = session['comment']
    		session.pop('comment')

    	flash('Thanks for submitting this form! You have submitted this form ' + str(session['counter']) + ' times now.')
    	return self.load_view('/surveys/result.html', name=name, location=location, language=language, comment=comment)

    def process(self):
    	session['counter'] += 1
    	session['name'] = request.form['name']
    	session['location'] = request.form['location']
    	session['language'] = request.form['language']

    	if "comment" in request.form:
    		session['comment'] = request.form['comment']

        return redirect('/result')
