from system.core.controller import *
import random as rnd

CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

class Index(Controller):
    def __init__(self, action):
        super(Index, self).__init__(action)
   
    def index(self):
        if "attempt" not in session:
            session['attempt'] = 0

        word = ""

        for i in range(14):
            word += CHARS[rnd.randrange(0, 36)]

        return self.load_view('/index/index.html', attempt=session['attempt'], word=word)

    def generate(self):
        session['attempt'] += 1
        return redirect('/')