from system.core.controller import *
import random as rnd
from time import strftime

class Index(Controller):
    def __init__(self, action):
        super(Index, self).__init__(action)

    def index(self):
        if 'balance' not in session:
            session['balance'] = 0

        if 'logs' not in session:
            session['logs'] = []

        return self.load_view('index.html', balance=session['balance'], logs=session['logs'])

    def process(self):
        _type = request.form['type']
        amount = 0
        
        if _type == "farm":
            amount = rnd.randrange(10, 21)
            session['logs'].append('Earned ' + str(amount) + ' golds from the farm! (' + str(strftime('%Y/%d/%m/ %I:%M %p') + ')').lower())

        elif _type == "cave":
            amount = rnd.randrange(5, 11)
            session['logs'].append('Earned ' + str(amount) + ' golds from the cave! (' + str(strftime('%Y/%d/%m/ %I:%M %p') + ')').lower())

        elif _type == "house":
            amount = rnd.randrange(2, 6)
            session['logs'].append('Earned ' + str(amount) + ' golds from the house! (' + str(strftime('%Y/%d/%m/ %I:%M %p') + ')').lower())

        elif _type == "casino":
            amount = rnd.randrange(0, 51)
            luck = round(rnd.random())

            if luck == 1:
                session['logs'].append('Entered a casino and lost ' + str(amount) + ' golds... Ouch. (' + str(strftime('%Y/%d/%m/ %I:%M %p') + ')').lower())
                amount = -amount
            else:
                session['logs'].append('Earned ' + str(amount) + ' golds from the casino! (' + str(strftime('%Y/%d/%m/ %I:%M %p') + ')').lower())
        
        session['balance'] += amount
        return redirect('/')


