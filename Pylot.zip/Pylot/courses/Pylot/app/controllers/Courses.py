from system.core.controller import *

class Courses(Controller):
    def __init__(self, action):
        super(Courses, self).__init__(action)
        self.load_model('Course')

    # GET
    def index(self):
        courses = self.models['Course'].get_courses()
        return self.load_view('index.html', courses=courses)

    # GET
    def remove(self, id):
        course = self.models['Course'].get_course(id)
        return self.load_view('/courses/remove.html', course=course[0])

    # POST
    def add(self):
        self.models['Course'].add_course(request.form['name'], request.form['description'])
        return redirect('/')

    # POST
    def delete(self):
        self.models['Course'].remove_course(request.form['id'])
        return redirect('/')

