from system.core.model import Model

class Course(Model):
    def __init__(self):
        super(Course, self).__init__()

    def get_courses(self):
        query = 'SELECT * FROM courses'
        return self.db.query_db(query)

    def get_course(self, id):
        query = 'SELECT * FROM courses WHERE id=:id'
        values = {
            "id": id
        }
        
        return self.db.query_db(query, values)

    def add_course(self, name, description):
        query = 'INSERT INTO courses (name, description, created_at) VALUES (:name, :description, NOW())'
        values = {
            "name": name,
            "description": description
        }

        self.db.query_db(query, values)
        return True

    def remove_course(self, id):
        query = 'DELETE FROM courses WHERE id=:id'
        values = {
            "id": id
        }

        self.db.query_db(query, values)
        return True