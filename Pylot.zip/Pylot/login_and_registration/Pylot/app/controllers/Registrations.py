from system.core.controller import *
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')

class Registrations(Controller):
    def __init__(self, action):
        super(Registrations, self).__init__(action)
        self.load_model('Registration')

    def index(self):
        if "id" in session:
            # Auto-Login for clients who have already logged in.
            return redirect('/success')

        return self.load_view('index.html')

    def success(self):
        if "id" not in session:
            # Add flash message, notifying that client is not logged in.
            return redirect('/')

        user = self.models['Registration'].get_user(session['id'])

        return self.load_view('success.html', user=user)

    def login(self):
        if 'email' not in request.form:
            flash('Please type a valid email.', 'lg_email')
            return redirect('/')

        email = request.form['email']

        if 'pw' not in request.form:
            flash('Please type a valid password.', 'lg_pw')
            return redirect('/')

        password = request.form['pw']
        result = self.models['Registration'].get_user(email, password)

        if not result:
            flash('Login failed! Are you sure your email and password is correct?', 'global')
            return redirect('/')

        session['id'] = result
        return redirect('/success')

    def register(self):
        if 'first_name' not in request.form:
            flash('Please type a valid first name.', 'first_name')
            return redirect('/')

        first_name = request.form['first_name']

        if not first_name.isalpha():
            flash('First name must be alphabetic.', 'first_name')
            return redirect('/')
            
        if len(first_name) < 2:
            flash('First name must be longer than 1 character.', 'first_name')
            return redirect('/')

        if 'last_name' not in request.form:
            flash('Please type a valid last name.', 'last_name')
            return redirect('/')

        last_name = request.form['last_name']

        if not last_name.isalpha():
            flash('Last name must be alphabetic.', 'last_name')
            return redirect('/')

        if len(last_name) < 2:
            flash('Last name must be longer than 1 character.', 'last_name')
            return redirect('/')

        if 'email' not in request.form:
            flash('Please type a valid email.', 'rg_email')
            return redirect('/')

        email = request.form['email']

        if not EMAIL_REGEX.match(email):
            flash('Please type a valid email.', 'rg_email')
            return redirect('/')

        if 'pw' not in request.form:
            flash('Please type a valid password.', 'rg_pw')
            return redirect('/')

        password = request.form['pw']

        if len(password) < 8:
            flash('Passwords must be longer than 8 characters.', 'rg_pw')
            return redirect('/')

        if 'pw_conf' not in request.form:
            flash('Please type a valid password.', 'rg_pw_conf')
            return redirect('/')

        password_confirm = request.form['pw_conf']

        if not password == password_confirm:
            flash('Password and Password Confirmation must match.', 'rg_pw_conf')
            return redirect('/')

        data = {
            "first_name": first_name,
            "last_name": last_name,
            "email": email,
            "password": password
        }

        self.models['Registration'].add_user(data)
        return redirect('/success')
        