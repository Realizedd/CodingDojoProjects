from system.core.model import Model

class Registration(Model):
    def __init__(self):
        super(Registration, self).__init__()

    def add_user(self, data):
        query = 'INSERT INTO users (first_name, last_name, email, pw_hash, created_at) VALUES (:first_name, :last_name, :email, :pw_hash, NOW())'
        data['pw_hash'] = self.bcrypt.generate_password_hash(data['password'])
        self.db.query_db(query, data)
        return True

    def get_user(self, email, password):
        query = 'SELECT * FROM users WHERE email=:email'
        values = {
            "email": email
        }

        user = self.db.query_db(query, values)
        print user
        if not user:
            return False

        user = user[0]

        if not self.bcrypt.check_password_hash(user['pw_hash'], password):
            return False

        return user['id']

    def get_user(self, id):
        query = 'SELECT * FROM users WHERE id=:id'
        values = {
            "id": id
        }

        result = self.db.query_db(query, values)

        if not result:
            return False

        return result[0]