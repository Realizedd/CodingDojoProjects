import UIKit

class AccessViewController: UIViewController {
    
    var enabled = [Int]()
    
    @IBAction func onChange(sender: UISwitch) {
        if sender.on {
            enabled.append(sender.tag)
        } else {
            enabled.removeAtIndex(enabled.indexOf(sender.tag)!)
        }
        
        if enabled == [3, 5, 2, 6] {
            enabled.removeAll()
            performSegueWithIdentifier("accessGranted", sender: sender)
        }
        
//        Example of: AlertViewController display
        
//        else {
//            let alert = UIAlertController(title: "ERROR", message: "Pattern is invalid. Please try again.", preferredStyle: UIAlertControllerStyle.Alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
//            presentViewController(alert, animated: true, completion: nil)
//        }

    }
}
