import UIKit

class CustomLayout: UICollectionViewLayout {
    
    let minimumLineSpacing: CGFloat = 0
    let minimumInteritemSpacing: CGFloat = 0
    let itemSize = CGSizeMake(320, 50)
    let headerReferenceSize = CGSizeMake(320, 50)
    let footerReferenceSize = CGSizeMake(320, 50)
    let sectionInset = UIEdgeInsetsMake(0, 0, 0, 0)
    
    let sectionHeadersPinToVisibleBounds = false
    
    var cache = [UICollectionViewLayoutAttributes]()
    
    override func collectionViewContentSize() -> CGSize {
        print("contentSize called:", collectionView!.bounds.size)
        return collectionView!.bounds.size
    }
    
    override func prepareLayout() {
        let SPACING: CGFloat = 5.0
        let ITEMS_PER_ROW: CGFloat = 7
        let viewWidth = collectionView!.bounds.width
        let width = (viewWidth - (ITEMS_PER_ROW * SPACING) - SPACING) / ITEMS_PER_ROW
        var x: CGFloat = SPACING
        var y: CGFloat = SPACING
        
        print("viewWidth:", viewWidth, "width:", width)
        
        for item in 0 ..< collectionView!.numberOfItemsInSection(0) {
//            print("x:", x, "y:", y)
            
            let indexPath = NSIndexPath(forItem: item, inSection: 0)
            let frame = CGRect(x: x, y: y, width: width, height: width)
            let attributes = UICollectionViewLayoutAttributes(forCellWithIndexPath: indexPath)
//            let insetFrame = CGRectInset(frame, SPACING, SPACING)
            attributes.frame = frame
            cache.append(attributes)
            
            x += width + SPACING

            if x + width > viewWidth {
                x = SPACING
                y += width + SPACING
            }
        }
    }
    
    override func layoutAttributesForElementsInRect(rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        var layoutAttributes = [UICollectionViewLayoutAttributes]()
        
        for attributes in cache {
            if CGRectIntersectsRect(attributes.frame, rect) {
                layoutAttributes.append(attributes)
            }
        }
        
        return layoutAttributes
    }
    
//    override func layoutAttributesForSupplementaryViewOfKind(elementKind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes? {
//        let attributes = UICollectionViewLayoutAttributes(forSupplementaryViewOfKind: elementKind, withIndexPath: indexPath)
//        attributes.frame = CGRect(x: 0, y: 0, width: 320, height: 50)
//        print("Called header")
//        return attributes
//    }
}
