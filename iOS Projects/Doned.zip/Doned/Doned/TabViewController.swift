//
//  TabViewController.swift
//  Doned
//
//  Created by Samuel on 10/7/16.
//  Copyright © 2016 Samuel Lim. All rights reserved.
//

import UIKit

extension UINavigationBar {
    
    var titleColor: UIColor? {
        get {
            if let attributes = self.titleTextAttributes {
                return attributes[NSForegroundColorAttributeName] as? UIColor
            }
            return nil
        }
        set {
            if let value = newValue {
                self.titleTextAttributes = [NSForegroundColorAttributeName: value]
            }
        }
    }
    
    var titleFont: UIFont? {
        get {
            if let attributes = self.titleTextAttributes {
                return attributes[NSFontAttributeName] as? UIFont
            }
            return nil
        }
        set {
            if let value = newValue {
                self.titleTextAttributes = [NSFontAttributeName: value]
            }
        }
    }
}

class TabViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.tintColor = UIColor.redColor()
        
        for controller in self.viewControllers! {
            let navController = controller as! UINavigationController
            navController.navigationBar.barTintColor = UIColor.blackColor()
            navController.navigationBar.tintColor = UIColor.redColor()
            navController.navigationBar.titleColor = UIColor.redColor()
        }
    }
}
